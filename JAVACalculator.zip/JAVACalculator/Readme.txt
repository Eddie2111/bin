open the file calculator.java to proceed
to run it you need java ide softwares.


Click the links below to get them,
Eclipse IDE-https://www.eclipse.org/downloads/
Netbeans IDE-https://netbeans.org/downloads/
drjava IDE-https://sourceforge.net/projects/drjava/

To know more about the project mail me:

Tarek42223@gmail.com